﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class AdventureGame : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI textComponent;
    [SerializeField] State startingState;

    //Cached Reference Variable
    State state;

    // Start is called before the first frame update
    void Start()
    {
        //textComponent.text = ("I am added Programmatically");
        state = startingState;
        textComponent.text = state.GetStateStory();
    }

    // Update is called once per frame
    void Update()
    {
        ManageState();        
    }

    private void ManageState()
    {
        var nextStates = state.GetNextStates();

        for(int index = 0; index < nextStates.Length; index++)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1 + index))
            {
                state = nextStates[index];
            }
        }

        textComponent.text = state.GetStateStory();

        //State[] nextStates = state.GetNextStates();

        /*
        if(Input.GetKeyDown(KeyCode.Alpha1))
        {
            state = nextStates[0];
        }

        else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            state = nextStates[1];
        }

        else if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            state = nextStates[2];
        }*/
    }
}
