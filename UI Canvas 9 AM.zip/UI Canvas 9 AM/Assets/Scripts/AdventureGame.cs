﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class AdventureGame : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI textComponent;

    // Start is called before the first frame update
    void Start()
    {
        textComponent.text = ("I am added Programmatically");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
